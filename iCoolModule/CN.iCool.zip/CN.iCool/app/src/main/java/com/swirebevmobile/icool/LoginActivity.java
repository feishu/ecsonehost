package com.swirebevmobile.icool;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.VolleyError;
import com.google.gson.JsonSyntaxException;
import com.swirebevmobile.icool.apis.LoginHelper;
import com.swirebevmobile.icool.apis.LoginResponse;
import com.swirebevmobile.icool.helpers.GlobalHelper;


public class LoginActivity extends AppCompatActivity implements LoginHelper.LoginApiResponseListener {

    private static final String TAG = LoginActivity.class.getName();

    TextView versionTextView;
    EditText phoneInputEditText;
    Button loginButton;
    TextView registerTextView;

    LoginHelper loginHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //set view
        versionTextView = (TextView) findViewById(R.id.versionTextView);
        phoneInputEditText = (EditText)findViewById(R.id.phoneEditText);
        loginButton = (Button) findViewById(R.id.loginButton);
        registerTextView = (TextView) findViewById(R.id.registerTextView);

        //set listeners
        loginButton.setOnClickListener(clickListener);
        registerTextView.setOnClickListener(clickListener);

        //set helper
        loginHelper = new LoginHelper(this);

        //set data
        setVersion();
    }

    // Create an anonymous implementation of OnClickListener
    private View.OnClickListener clickListener = new View.OnClickListener() {
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.loginButton:
                    if(loginHelper != null) {
                        loginHelper.call(LoginActivity.this);
                    }
                    break;
                case R.id.registerTextView:
                    Log.d(TAG, "register textview clicked");
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void onLoginResponse(LoginResponse response) {
        Log.d(TAG, "onLoginResponse: " + response.toString());
    }

    @Override
    public void onLoginError(String errorMsg) {
        Log.e(TAG, "login error:" + errorMsg);
    }


    void setVersion() {
        versionTextView.setText(GlobalHelper.getVersionName(this));

    }
}
