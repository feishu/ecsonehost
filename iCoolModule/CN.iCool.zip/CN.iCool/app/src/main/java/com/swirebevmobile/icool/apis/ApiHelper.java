package com.swirebevmobile.icool.apis;

import android.content.Context;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.swirebevmobile.icool.R;

/**
 * Created by lipy on 9/11/2017.
 */

public class ApiHelper {

    private static final String TAG = ApiHelper.class.getName();

    private static ApiHelper instance;

    private static RequestQueue queue;

    public static ApiHelper getInstance(Context context) {
        if (instance == null) {
            instance = new ApiHelper();
            queue = Volley.newRequestQueue(context);
        }
        return instance;
    }

    public static void call(StringRequest stringRequest) {
        Log.d(TAG, "api call: " + stringRequest.getUrl());
        queue.add(stringRequest);
    }

    public static String getApiDomain(Context context) {
        return context.getString(R.string.api_domain);
    }

}
