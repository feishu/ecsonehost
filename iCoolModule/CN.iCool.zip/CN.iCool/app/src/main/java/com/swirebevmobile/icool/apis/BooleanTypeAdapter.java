package com.swirebevmobile.icool.apis;
import java.lang.reflect.Type;
import com.google.gson.*;

/**
 * Created by lipy on 9/11/2017.
 */



class BooleanTypeAdapter implements JsonDeserializer<Boolean>
{
    public Boolean deserialize(JsonElement json, Type typeOfT,
                               JsonDeserializationContext context) throws JsonParseException
    {
        int code = json.getAsInt();
        return code == 0 ? false :
                code == 1 ? true :
                        null;
    }
}