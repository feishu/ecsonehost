package com.swirebevmobile.icool.apis;

import com.google.gson.annotations.SerializedName;

/**
 * Created by lipy on 9/11/2017.
 */

public class LoginResponse extends GeneralResponse{

    @SerializedName("scanningScreenFlag")
    boolean isPermisionRematchRFID;

    @SerializedName("marketCustomerScanFlag")
    boolean isPermissionCustomerScan;

    @SerializedName("marketScanFlag")
    boolean isPermissionDeviceScan;

    @SerializedName("plantFlag")
    boolean isPermissionPlantScan;

    @SerializedName("token")
    String token;

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(LoginResponse.class.getName());
        stringBuilder.append("status:" + status + " ");
        stringBuilder.append("messageText: " + messageText + " ");
        stringBuilder.append("scanningScreenFlag: " + isPermisionRematchRFID + " ");
        stringBuilder.append("marketCustomerScanFlag: " + isPermissionCustomerScan + " ");
        stringBuilder.append("marketScanFlag: " + isPermissionDeviceScan + " ");
        stringBuilder.append("plantFlag: " + isPermissionPlantScan + " ");
        stringBuilder.append("token: " + token);
        return stringBuilder.toString();
    }

}
