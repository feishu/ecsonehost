package com.swirebevmobile.icool.helpers;

import android.content.Context;
import android.support.compat.BuildConfig;
import android.util.Log;

/**
 * Created by lipy on 9/8/2017.
 */

public class GlobalHelper {

    private static final String TAG = GlobalHelper.class.getName();

    private static GlobalHelper instance;

    public static GlobalHelper getInstance() {
        if (instance == null) {
            instance = new GlobalHelper();
        }
        return instance;
    }

    public static final String getVersionName(Context context) {
        String versionName = "";
        try {
             versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        }
        catch (Exception e) {
            Log.e(TAG, "error getting versionName: " + e);
        }

        return versionName;

    }
}
