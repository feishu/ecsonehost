package com.swirebevmobile.icool.apis;

import com.google.gson.annotations.SerializedName;

/**
 * Created by lipy on 9/11/2017.
 */

public class GeneralResponse {

    @SerializedName("status")
    int status;

    @SerializedName("messageText")
    String messageText;
}
