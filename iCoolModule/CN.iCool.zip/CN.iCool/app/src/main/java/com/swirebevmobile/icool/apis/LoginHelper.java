package com.swirebevmobile.icool.apis;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

/**
 * Created by lipy on 9/11/2017.
 */

public class LoginHelper {

    //temp url for testing
    private static final String endpoint = "loginWithPhone";

    GsonBuilder gsonBuilder = new GsonBuilder();
    private Gson gson;

    public interface LoginApiResponseListener {
        void onLoginResponse(LoginResponse response);
        void onLoginError(String errorMsg);
    }

    private static final String TAG = LoginHelper.class.getName();

    private LoginApiResponseListener apiResponseListener;

    public LoginHelper(LoginApiResponseListener apiResponseListener) {
        this.apiResponseListener = apiResponseListener;

        gsonBuilder.registerTypeAdapter(boolean.class, new BooleanTypeAdapter());
        gson = gsonBuilder.create();
    }

    public void call(Context context) {
        String url = ApiHelper.getApiDomain(context) + endpoint;
        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(apiResponseListener != null) {
                            try {
                                LoginResponse loginResponse = gson.fromJson(response, LoginResponse.class);
                                apiResponseListener.onLoginResponse(loginResponse);
                            }
                            catch(JsonSyntaxException e) {
                               apiResponseListener.onLoginError(e.toString());
                            }
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "error calling:[" + endpoint + "], error:" + error.toString());

                if(apiResponseListener != null) {
                    apiResponseListener.onLoginError(error.getMessage());
                }
            }
        });

        ApiHelper.getInstance(context).call(stringRequest);
    }
}
