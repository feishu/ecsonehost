

::sign APK
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore sbicool.keystore  app\build\outputs\apk\app-release-unsigned.apk SBICOOLKEY

::verify
jarsigner -verify -verbose -certs  app\build\outputs\apk\app-release-unsigned.apk

::zipalign
%ANDROID_HOME%\build-tools\23.0.1\zipalign -v 4 app\build\outputs\apk\app-release-unsigned.apk app\build\outputs\apk\icool-release-signed.apk
